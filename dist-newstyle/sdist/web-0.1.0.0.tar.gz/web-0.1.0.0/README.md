# web

### Hlint:

Hlint is available as a standalone command-line tool. You can download it from Hackage, the Haskell package repository, using the following command:
`stack install hlint`
Once installed, you can run Hlint from the command line within your project directory to lint your Haskell code.
Some IDEs, such as Haskell-specific IDEs like Haskell for Mac or Atom with ide-haskell, may have built-in integration with Hlint, allowing you to see linting suggestions directly within your editor.

Completed 25 action(s).
Copying from C:\sr\snapshots\ed14e4d4\bin\hlint.exe to C:\Users\habiba.ahmed\AppData\Roaming\local\bin\hlint.exe.
Copied executables to C:\Users\habiba.ahmed\AppData\Roaming\local\bin\:
* hlint.exe

### Hoogle:

Hoogle is primarily a web-based tool, and you can access it through its website: https://hoogle.haskell.org/.
However, there are also command-line versions of Hoogle available that you can use to perform searches from the terminal. You can install Hoogle using Haskell's package manager, Cabal:
`stack install hoogle`
After installation, you can run hoogle commands from the terminal to search for Haskell functions, types, and modules.
Copying from C:\sr\snapshots\15ab2515\bin\hoogle.exe to C:\Users\habiba.ahmed\AppData\Roaming\local\bin\hoogle.exe.
Copied executables to C:\Users\habiba.ahmed\AppData\Roaming\local\bin\:
* hoogle.exe

### Ormolu:

Ormolu is available as a standalone command-line tool and can be installed using Cabal:
`stack install ormolu`

Once installed, you can run Ormolu from the command line within your project directory to format your Haskell code according to a predefined style.
Some Haskell development environments may also offer built-in support or plugins for Ormolu, allowing you to format code directly within your IDE.
After downloading and installing these tools, you can use them within your IntelliJ IDEA environment by executing them from the command line or integrating them into your build process. 



query vs query_:

The query function is used to execute a parameterized query that returns a result set. It takes three arguments: a Connection, a SQL query string with placeholders for parameters, and a tuple of parameters.
The query_ function is used for queries that don't have any parameters. It only takes two arguments: a Connection and a SQL query string without placeholders.