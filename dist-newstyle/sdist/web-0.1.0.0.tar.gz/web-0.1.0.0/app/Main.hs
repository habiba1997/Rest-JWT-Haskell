{-# OPTIONS_GHC -Wno-name-shadowing #-}
{-# LANGUAGE OverloadedStrings #-}
{-# OPTIONS_GHC -Wunused-imports #-}
module Main (main) where

import RoutesLib
import Database.PostgreSQL.Simple
--import Data.Aeson (encode, decode)
--import Control.Monad.IO.Class (liftIO)

localPG :: ConnectInfo
localPG =
  defaultConnectInfo
    { connectHost = "localhost",
      connectPort = 5436,
      connectDatabase = "products",
      connectUser = "postgres",
      connectPassword = "123456"
    }

main :: IO ()
main = do
    conn <- connect localPG
    routes conn
    -- Insert a new product into the database
--    _ <- execute conn "INSERT INTO products (name, price, description) VALUES (?, ?, ?)" ("Laptop" :: String, 100 :: Int, "A powerful laptop" :: String)

    -- Retrieve all products from the database and print them
--    products <- query_ conn "SELECT * FROM products" :: IO [Product]
--     --    In this example, putStrLn "All Products:" is an IO action that is lifted into the monadic context m using liftIO.
--    liftIO $ putStrLn "All Products:"
--    liftIO $ mapM_ print products

    -- Convert a Product to JSON
--    let productJson = encode (Product 1 "Phone" 500 "A smartphone")
--    putStrLn "Product JSON:"
--    BS.putStrLn productJson
--
--    -- Parse JSON into a Product
--    let parsedProduct = decode "{\"id\":2,\"name\":\"Tablet\",\"price\":300,\"description\":\"A portable tablet\"}" :: Maybe Product
--    putStrLn "Parsed Product:"
--    print parsedProduct

    -- Close the database connection
    close conn